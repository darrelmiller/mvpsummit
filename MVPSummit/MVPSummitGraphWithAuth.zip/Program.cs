﻿using Microsoft.Graph;
using Microsoft.Graph.Auth;
using System;
using System.Threading.Tasks;

namespace MVPSummit
{
    class Program
    {

        static void Main(string[] args)
        {
            AsyncMain().GetAwaiter().GetResult();
            Console.Read();
        }

        static async Task AsyncMain()
        {
            // Create Client Application and Authentication Provider
            var app = InteractiveAuthenticationProvider.CreateClientApplication("5dba030e-37f3-4adc-8eb8-3e2e9e68aa0f");
            var authProviders = new InteractiveAuthenticationProvider(app, new string[] { "User.Read"});

            // Create GraphServiceClient with middleware pipeline setup
            var graphServiceClient = new GraphServiceClient(authProviders);

            // Request using default app permissions
            var user = await graphServiceClient.Me.Request().GetAsync();
            Console.WriteLine($"User: {user.DisplayName}");

            // Incremental Consent
            var messages = await graphServiceClient.Me.Messages.Request()
                .WithScopes(new string[] { "Mail.Read" })
                .GetAsync();
            Console.WriteLine($"Messages Count: {messages.Count}");

            Console.Read();
        }
    }
}
